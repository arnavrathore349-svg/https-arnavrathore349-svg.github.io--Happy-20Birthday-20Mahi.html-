(()=>{
const NAME='Mahi', FL=[{"src": "assets/flame1.png", "x": 26.45, "y": 46.15, "w": 6.294, "h": 8.45}, {"src": "assets/flame2.png", "x": 41.867, "y": 48.25, "w": 5.799, "h": 7.7}, {"src": "assets/flame3.png", "x": 60.113, "y": 47.45, "w": 5.941, "h": 7.75}];
const $=id=>document.getElementById(id), leaves=[$('l0'),$('l1'),$('l2')], bar=$('bar'), note=$('note'), stage=$('stage');
let page=0, letterOpen=false;
/* ---------- pages ---------- */
function btn(t,fn,id){const b=document.createElement('button');b.textContent=t;if(id)b.id=id;b.onclick=fn;return b}
function go(n){clearTimeout(w2t);$('w2').classList.remove('show');
  const back=n<page; page=n;
  leaves.forEach((l,i)=>{l.classList.toggle('back',back);l.classList.toggle('flipped',i<n)});
  if(n!==1) setLetter(false);
  bar.innerHTML=''; note.classList.toggle('hide',n!==2);
  if(n===0){bar.append(Object.assign(document.createElement('span'),{className:'hint',textContent:'tap the cover to open ✿'}));stopBlow()}
  if(n===1){bar.append(btn('‹ back to cover',()=>go(0)),btn('next ›',()=>go(2)));stopBlow()}
  if(n===2){buildCake()}
}
$('l0').onclick=()=>{if(page===0){startMusic();go(1)}};
/* ---------- letter ---------- */
function setLetter(o){letterOpen=o;$('l1').classList.toggle('open',o)}
$('spot').onclick=()=>setLetter(true);
$('letter').onclick=e=>{e.stopPropagation();setLetter(false)};
$('dim').onclick=()=>setLetter(false);
/* ---------- flames ---------- */
const fw=$('flames');
FL.forEach((f,i)=>{
  const d=document.createElement('div');d.className='flame';
  d.style.cssText=`left:${f.x}%;top:${f.y}%;width:${f.w}%;height:${f.h}%`;
  d.innerHTML=`<img src="${f.src}" alt="">`;fw.append(d);
  const s=document.createElement('div');s.className='smoke';s.style.cssText=`left:${f.x+f.w/2-2.5}%;top:${f.y+f.h*.3}%`;fw.append(s);
});
const flames=[...fw.querySelectorAll('.flame')], smokes=[...fw.querySelectorAll('.smoke')];
/* ---------- blowing ---------- */
let w2t,out=false, blowT=0, level=0, hold=false, micOn=false, raf=0, last=0, ctx, an, data, floor=0.01, stream;
const meter=document.createElement('div');meter.className='meter';meter.innerHTML='<i></i><b></b>';
function buildCake(){
  bar.append(btn('‹ back',()=>go(1)),btn('back to cover',()=>go(0)),btn('🎤 use mic',startMic,'micBtn'));
  const hb=btn('hold to blow 💨',null,'holdBtn');
  ['pointerdown'].forEach(ev=>hb.addEventListener(ev,e=>{e.preventDefault();hold=true;hb.classList.add('on')}));
  ['pointerup','pointerleave','pointercancel'].forEach(ev=>hb.addEventListener(ev,()=>{hold=false;hb.classList.remove('on')}));
  bar.append(hb,meter);
  const secure=window.isSecureContext&&navigator.mediaDevices&&navigator.mediaDevices.getUserMedia;
  note.textContent=secure?'Tap “use mic”, then blow gently at your phone for half a second. No mic? Hold the button (or the spacebar).':'Mic blowing only works when this file is hosted over https (not opened locally). Until then, hold the button or the spacebar to blow.';
  if(!out) run();
}
async function startMic(){
  if(micOn) return;
  try{
    stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
    ctx=new (window.AudioContext||window.webkitAudioContext)();await ctx.resume();
    an=ctx.createAnalyser();an.fftSize=1024;ctx.createMediaStreamSource(stream).connect(an);data=new Float32Array(an.fftSize);
    micOn=true;floor=0.01;setDuck(!out);$('micBtn').textContent='🎤 listening…';
  }catch(e){note.textContent='Couldn’t use the mic ('+(e.name||'blocked')+'). Hold the button or the spacebar to blow instead.';note.classList.remove('hide')}
}
function stopBlow(){setDuck(false);cancelAnimationFrame(raf);raf=0;hold=false;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}if(ctx){ctx.close();ctx=null}micOn=false;level=0}
function run(){cancelAnimationFrame(raf);last=performance.now();raf=requestAnimationFrame(tick)}
function tick(t){
  const dt=Math.min(.05,(t-last)/1000);last=t;
  let target=0;
  if(micOn&&an){an.getFloatTimeDomainData(data);let s=0;for(const v of data)s+=v*v;const rms=Math.sqrt(s/data.length);
    if(rms<floor+.03)floor+=(rms-floor)*.02;target=Math.max(0,Math.min(1,(rms-floor-.03)/.22))}
  if(hold)target=Math.max(target,.9);
  level+=(target-level)*Math.min(1,dt*14);
  meter.firstChild.style.width=(level*100)+'%';
  const blowing=level>.25;
  if(!out){
    blowT=blowing?blowT+dt:Math.max(0,blowT-dt*2);
    flames.forEach(f=>f.style.setProperty('--b',Math.min(42,level*50)));
    if(blowT>=.5)extinguish();
  }
  raf=requestAnimationFrame(tick);
}
addEventListener('keydown',e=>{if(e.code==='Space'&&page===2){e.preventDefault();hold=true;$('holdBtn')&&$('holdBtn').classList.add('on')}});
addEventListener('keyup',e=>{if(e.code==='Space'){hold=false;$('holdBtn')&&$('holdBtn').classList.remove('on')}});
function extinguish(){
  out=true;setDuck(false);
  flames.forEach((f,i)=>setTimeout(()=>{f.classList.add('out');smokes[i].classList.add('go')},i*110));
  setTimeout(()=>{$('wish').classList.add('show');confetti()},650);
  w2t=setTimeout(()=>$('w2').classList.add('show'),3400);
}
$('w2').onclick=e=>{if(e.target.id!=='relight2')$('w2').classList.remove('show')};
$('relight2').onclick=()=>$('relight').click();
$('relight').onclick=()=>{clearTimeout(w2t);$('w2').classList.remove('show');
  out=false;blowT=0;if(micOn)setDuck(true);$('wish').classList.remove('show');
  flames.forEach(f=>{f.classList.remove('out');f.style.setProperty('--b',0)});
  smokes.forEach(s=>s.classList.remove('go'));
};
/* ---------- confetti ---------- */
function confetti(){
  const c=$('conf'),r=stage.getBoundingClientRect(),dpr=devicePixelRatio||1;
  c.width=r.width*dpr;c.height=r.height*dpr;const g=c.getContext('2d');g.scale(dpr,dpr);
  const cols=['#ff5fa2','#ffd23f','#27b3b0','#ff8a3d','#f6e7c8','#7a5cff'],P=[];
  for(let i=0;i<150;i++)P.push({x:r.width/2+(Math.random()-.5)*60,y:r.height*.55,vx:(Math.random()-.5)*14,vy:-Math.random()*16-4,w:6+Math.random()*7,h:4+Math.random()*5,a:Math.random()*6,va:(Math.random()-.5)*.4,c:cols[i%cols.length]});
  const t0=performance.now();
  (function f(t){g.clearRect(0,0,r.width,r.height);const e=t-t0;
    P.forEach(p=>{p.vy+=.35;p.vx*=.99;p.x+=p.vx;p.y+=p.vy;p.a+=p.va;g.save();g.globalAlpha=Math.max(0,1-(e-2600)/1400);g.translate(p.x,p.y);g.rotate(p.a);g.fillStyle=p.c;g.fillRect(-p.w/2,-p.h/2,p.w,p.h);g.restore()});
    if(e<4000)requestAnimationFrame(f);else g.clearRect(0,0,r.width,r.height)})(t0);
}
/* ---------- background song ---------- */
const song=$('song');let musicWanted=false,duck=false;
function applyGain(){const on=musicWanted&&!duck;if(on){const p=song.play();p&&p.catch&&p.catch(()=>{})}else song.pause();$('mus').textContent=musicWanted?'♪ on':'♪ off'}
function setDuck(v){duck=v;applyGain()}
function startMusic(){musicWanted=true;song.volume=.7;applyGain()}
$('mus').onclick=()=>{if(musicWanted){musicWanted=false;applyGain()}else startMusic()};
go(0);
window.__go=go;
})();
